#include <iostream>
using namespace std;
#include "functions.h"


void add(){
   cout<< " enter two numbers";
    int a, b;
	cin>>  a >> b ;
    cout << "Sum is : " << a+b << endl;
}
