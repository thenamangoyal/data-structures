void hello();
int factorial(int n);
void add();
