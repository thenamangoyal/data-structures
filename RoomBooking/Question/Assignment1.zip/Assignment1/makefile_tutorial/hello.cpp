#include <iostream>
using namespace std;
#include "functions.h"


void hello(){
   cout << "Hello IIT Ropar";
}
